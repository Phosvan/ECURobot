import pygame
import socket
import time
import math

srv_address = ('',32768)

############
# CONFIGURE WINDOW ELEMENTS HERE
############

black = pygame.Color('black')
white = pygame.Color('white')
red = pygame.Color('red')
degree = u"\u00b0"
multFact = 10

windowSize = 1000; #Window size to be declared as an even number
halfWindowSize = (windowSize/2)

xSum = halfWindowSize
ySum = halfWindowSize

class TextPrint(object):
	def __init__(self):
		self.reset()
		self.font = pygame.font.Font(None, 20)

	def tprint(self, screen, textString):
		textBitmap = self.font.render(textString, True, black)
		screen.blit(textBitmap, (self.x, self.y))
		self.y += self.line_height

	def reset(self):
		self.x = 10
		self.y = 10
		self.line_height = 15

	def indent(self):
		self.x += 10

	def unindent(self):
		self.x -= 10

pygame.init()

screen = pygame.display.set_mode((windowSize,windowSize))
pygame.display.set_caption("Control Vector")

done = False

clock = pygame.time.Clock()

cartesianText = TextPrint()

def receive_data():
		data = sock.recv(128)
		return data.decode('utf-8')


while not done:

	sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
	sock.connect(srv_address)
	#
	#
	#######################################################################

	#######################################################################
	# Get the network packet
	#
	udp_controls = str(receive_data())
	""" NOTE: MAY BE USEFUL FOR TESTING
	if (udp_controls == 'QUIT'):
		break
	"""
	# Parse the packet...
	prs_controls = list(udp_controls)
	prs_controls.pop(0)
	prs_controls.pop(len(prs_controls)-1)
	prs_controls = ''.join(prs_controls)
	prs_controls = prs_controls.split(',')
	# End parsing

	# Convert parsed packet into useable values
	p_axes    = [
		float(prs_controls[0]),
		float(prs_controls[1]),
		float(prs_controls[2]),
		float(prs_controls[3])
	]

	p_buttons = [
		int(prs_controls[4]),
		int(prs_controls[5]),
		int(prs_controls[6]),
		int(prs_controls[7]),
		int(prs_controls[8]),
		int(prs_controls[9]),
		int(prs_controls[10]),
		int(prs_controls[11]),
		int(prs_controls[12]),
		int(prs_controls[13]),
		int(prs_controls[14]),
		float(prs_controls[15]),
		float(prs_controls[16])
	]
	screen.fill(white)

	pygame.draw.line(screen, black, (0,halfWindowSize), (windowSize,halfWindowSize))
	pygame.draw.line(screen, black, (halfWindowSize,0), (halfWindowSize, windowSize))

	cartesianText.reset()
	cartesianText.tprint(screen, "Control Vector")
	cartesianText.tprint(screen, ("LTS: %.3f, %.3f")%(p_axes[0], p_axes[1]))
	cartesianText.tprint(screen, ("RTS: %.3f, %.3f")%(p_axes[2],p_axes[3]))

	#### Map RX'd data to WindowSize
	xValue = (((p_axes[2]*halfWindowSize)+halfWindowSize))
	xValue = round(xValue)
	yValue = (((p_axes[1]*halfWindowSize)+halfWindowSize))
	yValue = round(yValue)

	#### Magnitude Calculation
	magnitude = math.sqrt(((-p_axes[1])*(-p_axes[1]))+((p_axes[2])*(p_axes[2])))
	heading = math.atan2((-p_axes[1]),p_axes[2])
	if (heading < 0):
		heading = heading + 2*math.pi
	heading = heading * (180/math.pi)

	cartesianText.tprint(screen, ("Current Magnitude: %.3f")%magnitude)
	cartesianText.tprint(screen, ("Current Heading: %.3f")%heading+degree)

	xSum = xSum + (p_axes[2]*multFact)
	ySum = ySum + (p_axes[1]*multFact)

	xSum = round(xSum)
	ySum = round(ySum)

	# MAP AXES TO WINDOW SIZE
	mappedX = p_axes[2]*100
	mappedY = p_axes[1]*100

	mappedX	= round(mappedX)
	mappedY = round(mappedY)

	cartesianText.tprint(screen, ("Current Location: <%.3f,%.3f>")%((xSum-halfWindowSize),(-(ySum-halfWindowSize))))

	pygame.draw.circle(screen, black, (xSum,ySum), 5)

	pygame.draw.circle(screen, red, ((xSum+mappedX),(ySum+mappedY)), 5)
	pygame.draw.line(screen, black, (xSum, ySum), ((xSum+mappedX), (ySum+mappedY)))

	

	pygame.display.flip()
	clock.tick(60)